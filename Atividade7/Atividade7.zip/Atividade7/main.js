function getMaior(num1, num2, num3){
    alert("O maior número é: " + Math.max(num1,num2,num3));
}
var num = [];
for(var i = 0; i<3; i++){
    num[i] = prompt("Informe o " + (i+1) + "º número");
}

getMaior(num[0],num[1],num[2]);
