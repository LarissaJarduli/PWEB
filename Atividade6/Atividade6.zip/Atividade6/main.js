var escolha = prompt('Qual você escolhe?');
escolha = escolha.toUpperCase();
var num = Math.random() * 10;
var escolha2;

if(num <= 3){
    escolha2 = 'PEDRA';
} else if (num <= 6){
    escolha2 = 'PAPEL';
} else {
    escolha2 = 'TESOURA';
}

if (escolha != 'PEDRA' && escolha != 'TESOURA' && escolha != 'PAPEL'){
    alert('Opção inválida.');
} else if(escolha == escolha2){
    alert(escolha+' vs '+escolha2+'\nEmpate!');
} else if((escolha == 'PEDRA' && escolha2 == 'TESOURA') || (escolha == 'PAPEL' && escolha2 == 'PEDRA') || (escolha == 'TESOURA' && escolha2 == 'PAPEL')){
    alert(escolha+' vs '+escolha2+'\nVitória!');
} else if((escolha == 'TESOURA' && escolha2 == 'PEDRA') || (escolha == 'PEDRA' && escolha2 == 'PAPEL') || (escolha == 'PAPEL' && escolha2 == 'TESOURA')){
    alert(escolha+' vs '+escolha2+'\nDerrota!');
}
