
$('#menu1').on("click", function() {
    $('#menu2').removeClass('active');
    $('#menu3').removeClass('active');
    $('#certificados').css('display','none');
    $('#experiencia').css('display','none');

    $('#menu1').toggleClass('active');
    $('#historico').slideToggle("slow"); 
});

$('#menu2').on("click", function() {
    $('#menu1').removeClass('active');
    $('#menu3').removeClass('active');
    $('#historico').css('display','none');
    $('#experiencia').css('display','none');

    $('#menu2').toggleClass('active');
    $('#certificados').slideToggle("slow");  
});

$('#menu3').on("click", function() {
    $('#menu2').removeClass('active');
    $('#menu1').removeClass('active');
    $('#historico').css('display','none');
    $('#certificados').css('display','none');

    $('#menu3').toggleClass('active');
    $('#experiencia').slideToggle("slow");
});



