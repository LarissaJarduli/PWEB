var app = require('./app/config/server'); // carregando o módulo do servidor

var rotaIndex = require('./app/routes/portifolio');
rotaIndex(app);

app.listen(3000, function(){
console.log("Servidor Iniciado");
});